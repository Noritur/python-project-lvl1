#!/usr/bin/env python3

def brain_games():
  print('Welcome to the Brain Games!')
def main():
  brain_games()
if __name__ == '__main__':
    main()

#!/usr/bin/env python3

from brain_games.func_even import brain_games, even_game


def main():
    brain_games()
    even_game()


if __name__ == '__main__':
    main()
